//
//  MeatTemperature.swift
//  pickerpractice WatchKit Extension
//
//  Created by Jaspreet on 2020-08-21.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var timer: WKInterfaceTimer!
    
      @IBOutlet weak var weightPicker: WKInterfacePicker!
      @IBOutlet weak var timerButton: WKInterfaceButton!
    
   
    
    var ounces = 16
    var cookTemp = MeatTemperature.medium
    var timerRunning = false
   
    
    override func awake(withContext context: Any?) {
      super.awake(withContext: context)
      var weightItems: [WKPickerItem] = []
      for i in 1...32 {
      // 2
      let item = WKPickerItem()
          item.title = String(i); weightItems.append(item)
      }
      // 3
      weightPicker.setItems(weightItems)
      // 4
      weightPicker.setSelectedItemIndex(ounces - 1)
        
        var tempItems: [WKPickerItem] = []
            for i in 1...4 {
            // 2
            let item = WKPickerItem()
            item.contentImage = WKImage(imageName: "temp-\(i)")
            tempItems.append(item)
            }
            // 3
            temperaturePicker.setItems(tempItems)
            // 4
            onTemperatureChanged(0)
      
    }
    
    
    
   
    
   
    
    @IBAction func onTimerButton() {
     // 1
      if timerRunning {
        timer.stop()
        timerButton.setTitle("Start Timer")
      } else {
        // 2
        let time = cookTemp.cookTimeForOunces(ounces)
        timer.setDate(Date(timeIntervalSinceNow: time))
        timer.start()
        timerButton.setTitle("Stop Timer")
      }
      // 3
      timerRunning = !timerRunning
      scroll(to: timer, at: .top, animated: true)
    }
    
    override func interfaceOffsetDidScrollToTop() {
      print("User scrolled to top")
    }
    
    override func interfaceDidScrollToTop() {
      print("User went to top by tapping status bar")
    }
    
    override func interfaceOffsetDidScrollToBottom() {
      print("User scrolled to bottom")
    }
    @IBAction func onWeightChanged(_ value: Int) {
    ounces = value + 1
    }
    
    
    @IBOutlet var temperatureLabel: WKInterfaceLabel!
    
    
    @IBOutlet var temperaturePicker: WKInterfacePicker!
 
    
    @IBAction func onTemperatureChanged(_ value: Float) {
        
        let temp = MeatTemperature(rawValue: Int(value))!
        cookTemp = temp
        temperatureLabel.setText(temp.stringValue)
    }
}
