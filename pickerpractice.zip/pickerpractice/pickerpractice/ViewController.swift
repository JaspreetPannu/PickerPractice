//
//  MeatTemperature.swift
//  pickerpractice WatchKit Extension
//
//  Created by Jaspreet on 2020-08-21.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

